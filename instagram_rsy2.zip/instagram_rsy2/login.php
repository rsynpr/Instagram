<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RuggedGuard</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="img/Rsy.png">
</style>
</head>
<body>
    <div class="container">
    <form action="proses_login.php" method="post">
        <div align="center">
            <img src="img/Rsy.png" width="90" height="90" alt="">
			<h2 class="title">RuggedGuard</h2>
        </div>

        <label for="username">Username</label>
        <input type="text" id="username" name="username" autocomplete="off" required placeholder=" enter username">

        <label for="password">Password</label>
        <input type="password" id="password" name="password" required placeholder="enter password" ><br>

        <button>Sign In</button>
    </form>
</div>
</body>
</html>